Team Members:
    Arnob Mallik (CCID: amallik)
    Arif Hasnat (CCID: hasnat)

Task 1 - Special Instructions:
	execute following commands:
		python3
		>> import nltk
		>> nltk.download('punkt')
		>> nltk.download('averaged_perceptron_tagger')

Task 1 - Execution Instruction:
    run the following command in command line:
        python3 task1.py DATA_FOLDER_PATH

    example:
        python3 task1.py ../a4_data



Task 2 - Special Instructions:
	execute following commands:
		pip3 install -U spacy
		python3 -m spacy download en_core_web_sm
	

Task 2 - Execution Instruction:

    run the following command in command line:
        python3 task2.py DATA_FOLDER_PATH

    example:
        python3 task2.py ../a4_data