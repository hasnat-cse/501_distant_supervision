Team Members:
    Arnob Mallik (CCID: amallik)
    Arif Hasnat (CCID: hasnat)

Special Instruction:
	execute following commands:
		python3
		>> import nltk
		>> nltk.download('punkt')

Execution Instruction:
    run the following command in command line:
        python3 task1.py DATA_FOLDER_PATH

    example:
        python3 task1.py ../a4_data