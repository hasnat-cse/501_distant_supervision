Team Members:
    Arnob Mallik (CCID: amallik)
    Arif Hasnat (CCID: hasnat)

Special Instructions:
	execute following commands:
		pip3 install -U spacy
		python3 -m spacy download en_core_web_sm


Execution Instruction:

    run the following command in command line:
        python3 task2.py DATA_FOLDER_PATH

    example:
        python3 task2.py ../a4_data